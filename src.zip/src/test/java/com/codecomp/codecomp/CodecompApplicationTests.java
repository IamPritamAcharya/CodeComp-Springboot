package com.codecomp.codecomp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodecompApplicationTests {

	@Test
	void contextLoads() {
	}

}
